<?php
session_start();
require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {

        session_start();
        $_SESSION['user_id'] = $user['id'];

        header("Location: ../dashboard.php");
        exit;

    } else {
        echo "Invalid login";
    }
}
?>

<form method="POST">
<input name="email" placeholder="Email"><br>
<input name="password" placeholder="Password"><br>
<button>Login</button>
</form>