<h1>Auth System</h1>

<a href="auth/register.php">Register</a><br>
<a href="auth/login.php">Login</a>